#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im41.err
#$ -i Si110_im41.input
#$ -o Si110_im41.out
#
/home/ayankovich/bin/autostem
