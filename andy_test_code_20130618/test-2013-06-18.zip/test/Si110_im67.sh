#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im67.err
#$ -i Si110_im67.input
#$ -o Si110_im67.out
#
/home/ayankovich/bin/autostem
