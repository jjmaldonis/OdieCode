#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im2.err
#$ -i Si110_im2.input
#$ -o Si110_im2.out
#
/home/ayankovich/bin/autostem
