#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im34.err
#$ -i Si110_im34.input
#$ -o Si110_im34.out
#
/home/ayankovich/bin/autostem
