#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im36.err
#$ -i Si110_im36.input
#$ -o Si110_im36.out
#
/home/ayankovich/bin/autostem
