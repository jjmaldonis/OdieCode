#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im39.err
#$ -i Si110_im39.input
#$ -o Si110_im39.out
#
/home/ayankovich/bin/autostem
