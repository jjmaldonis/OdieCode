#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im58.err
#$ -i Si110_im58.input
#$ -o Si110_im58.out
#
/home/ayankovich/bin/autostem
