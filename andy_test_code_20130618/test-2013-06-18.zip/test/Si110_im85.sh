#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im85.err
#$ -i Si110_im85.input
#$ -o Si110_im85.out
#
/home/ayankovich/bin/autostem
