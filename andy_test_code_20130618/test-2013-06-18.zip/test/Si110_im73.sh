#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im73.err
#$ -i Si110_im73.input
#$ -o Si110_im73.out
#
/home/ayankovich/bin/autostem
