#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im84.err
#$ -i Si110_im84.input
#$ -o Si110_im84.out
#
/home/ayankovich/bin/autostem
