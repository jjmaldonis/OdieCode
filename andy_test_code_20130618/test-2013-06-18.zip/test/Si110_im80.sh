#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im80.err
#$ -i Si110_im80.input
#$ -o Si110_im80.out
#
/home/ayankovich/bin/autostem
