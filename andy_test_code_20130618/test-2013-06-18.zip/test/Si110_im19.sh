#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im19.err
#$ -i Si110_im19.input
#$ -o Si110_im19.out
#
/home/ayankovich/bin/autostem
