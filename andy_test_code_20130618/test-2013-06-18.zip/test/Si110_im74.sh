#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im74.err
#$ -i Si110_im74.input
#$ -o Si110_im74.out
#
/home/ayankovich/bin/autostem
