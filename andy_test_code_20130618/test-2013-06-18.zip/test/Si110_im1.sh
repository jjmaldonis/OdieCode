#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im1.err
#$ -i Si110_im1.input
#$ -o Si110_im1.out
#
/home/ayankovich/bin/autostem
