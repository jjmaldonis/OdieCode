#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im23.err
#$ -i Si110_im23.input
#$ -o Si110_im23.out
#
/home/ayankovich/bin/autostem
