#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im77.err
#$ -i Si110_im77.input
#$ -o Si110_im77.out
#
/home/ayankovich/bin/autostem
