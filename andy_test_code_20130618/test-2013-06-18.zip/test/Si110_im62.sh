#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im62.err
#$ -i Si110_im62.input
#$ -o Si110_im62.out
#
/home/ayankovich/bin/autostem
