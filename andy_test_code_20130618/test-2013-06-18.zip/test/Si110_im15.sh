#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im15.err
#$ -i Si110_im15.input
#$ -o Si110_im15.out
#
/home/ayankovich/bin/autostem
