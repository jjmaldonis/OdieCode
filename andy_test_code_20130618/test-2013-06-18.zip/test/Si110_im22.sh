#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im22.err
#$ -i Si110_im22.input
#$ -o Si110_im22.out
#
/home/ayankovich/bin/autostem
