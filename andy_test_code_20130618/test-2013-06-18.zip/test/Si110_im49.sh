#!/bin/bash
#
#$ -cwd
#$ -m be
#$ -M ayankovich@wisc.edu
#$ -S /bin/bash
#$ -e Si110_im49.err
#$ -i Si110_im49.input
#$ -o Si110_im49.out
#
/home/ayankovich/bin/autostem
